import 'dart:io';
import 'dart:math' as math;
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:path_provider/path_provider.dart';
import 'package:pdf/widgets.dart' as pw;
import 'package:excel/excel.dart';
import 'package:share_plus/share_plus.dart';
import 'package:shared_preferences/shared_preferences.dart';

void main()=>runApp(ChangeNotifierProvider(create:(_)=>CabinetModel(),child:const App()));

class Cut{final String name,edge;final double w,h;final int qty;Cut(this.name,this.w,this.h,this.qty,this.edge);}
class CabinetModel extends ChangeNotifier{
 double width=900,height=2100,depth=600,thickness=18;int shelves=3,drawers=2,doors=2;bool back=true;
 String doorStyle='Overlay',edge='Front edges';
 List<Cut> get cuts{
  final iw=math.max(1,width-2*thickness),ih=math.max(1,height-2*thickness);
  final a=<Cut>[Cut('Left side',depth,height,1,edge),Cut('Right side',depth,height,1,edge),Cut('Top',iw,depth,1,edge),Cut('Bottom',iw,depth,1,edge)];
  if(shelves>0)a.add(Cut('Adjustable shelf',iw,depth,shelves,edge));
  if(drawers>0)a.add(Cut('Drawer front',iw,180,drawers,edge));
  if(doors>0)a.add(Cut('Door',height,width/doors,doors,edge));
  if(back)a.add(Cut('Back panel',iw,ih,1,'No'));
  return a;
 }
 double get area=>cuts.fold(0,(s,c)=>s+c.w*c.h*c.qty);
 int get sheets=>math.max(1,(area/(2440*1220)).ceil());
 void changed()=>notifyListeners();
 Future<void> save()async{final p=await SharedPreferences.getInstance();await p.setString('cabinet','${width},${height},${depth},${thickness}');}
}

class App extends StatelessWidget{const App({super.key});@override Widget build(BuildContext c)=>MaterialApp(debugShowCheckedModeBanner:false,title:'Melamina Pro',theme:ThemeData(colorSchemeSeed:Colors.indigo,useMaterial3:true),home:const Home());}
class Home extends StatelessWidget{const Home({super.key});@override Widget build(BuildContext c)=>DefaultTabController(length:3,child:Scaffold(
 appBar:AppBar(title:const Text('Melamina Pro 3D'),actions:[IconButton(onPressed:()=>c.read<CabinetModel>().save(),icon:const Icon(Icons.save))],bottom:const TabBar(tabs:[Tab(text:'Designer'),Tab(text:'Cut List'),Tab(text:'Quotation')])),
 body:const TabBarView(children:[Designer(),CutList(),Quote()])));}

class Field extends StatelessWidget{final String label;final double value;final ValueChanged<double> onChanged;const Field({super.key,required this.label,required this.value,required this.onChanged});
 @override Widget build(BuildContext c)=>TextFormField(initialValue:value.toStringAsFixed(0),keyboardType:TextInputType.number,decoration:InputDecoration(labelText:label,suffixText:'mm',border:const OutlineInputBorder()),onChanged:(v)=>onChanged(double.tryParse(v)??value));}

class Designer extends StatelessWidget{const Designer({super.key});@override Widget build(BuildContext c)=>Consumer<CabinetModel>(builder:(c,m,_)=>
 SingleChildScrollView(padding:const EdgeInsets.all(12),child:Column(children:[
  SizedBox(height:320,child:Card(child:CustomPaint(painter:Painter(m),child:const SizedBox.expand()))),
  Wrap(spacing:8,runSpacing:8,children:[
   SizedBox(width:165,child:Field(label:'Width',value:m.width,onChanged:(v){m.width=v;m.changed();})),
   SizedBox(width:165,child:Field(label:'Height',value:m.height,onChanged:(v){m.height=v;m.changed();})),
   SizedBox(width:165,child:Field(label:'Depth',value:m.depth,onChanged:(v){m.depth=v;m.changed();})),
   SizedBox(width:165,child:Field(label:'Board thickness',value:m.thickness,onChanged:(v){m.thickness=v;m.changed();})),
  ]),
  const SizedBox(height:10),Drop('Door style',m.doorStyle,['Overlay','Inset','Slab','Framed'],(v){m.doorStyle=v!;m.changed();}),
  Drop('Edge banding',m.edge,['Front edges','All visible edges','No edge banding'],(v){m.edge=v!;m.changed();}),
  SliderRow('Shelves',m.shelves,0,8,(v){m.shelves=v;m.changed();}),
  SliderRow('Drawers',m.drawers,0,8,(v){m.drawers=v;m.changed();}),
  SliderRow('Doors',m.doors,0,4,(v){m.doors=v;m.changed();}),
  SwitchListTile(title:const Text('6 mm back panel'),value:m.back,onChanged:(v){m.back=v;m.changed();})
 ]));}
class Drop extends StatelessWidget{final String label,value;final List<String> items;final ValueChanged<String?> onChanged;const Drop(this.label,this.value,this.items,this.onChanged,{super.key});
 @override Widget build(BuildContext c)=>DropdownButtonFormField<String>(value:value,decoration:InputDecoration(labelText:label,border:const OutlineInputBorder()),items:items.map((x)=>DropdownMenuItem(value:x,child:Text(x))).toList(),onChanged:onChanged);}
class SliderRow extends StatelessWidget{final String label;final int value,min,max;final ValueChanged<int> onChanged;const SliderRow(this.label,this.value,this.min,this.max,this.onChanged,{super.key});
 @override Widget build(BuildContext c)=>Row(children:[Expanded(child:Slider(value:value.toDouble(),min:min.toDouble(),max:max.toDouble(),divisions:max-min,label:'$label $value',onChanged:(v)=>onChanged(v.round()))),Text('$label: $value')]);}

class Painter extends CustomPainter{final CabinetModel m;Painter(this.m);@override void paint(Canvas c,Size s){
 final sc=math.min((s.width-70)/(m.width+m.depth*.35),(s.height-60)/m.height),x=30.0,y=35.0,w=m.width*sc,h=m.height*sc,d=m.depth*.35*sc;
 final fill=Paint()..color=Colors.blueGrey.shade100; c.drawRect(Rect.fromLTWH(x,y,w,h),fill);
 final top=Path()..moveTo(x,y)..lineTo(x+d,y-d*.45)..lineTo(x+w+d,y-d*.45)..lineTo(x+w,y)..close();c.drawPath(top,Paint()..color=Colors.blueGrey.shade300);
 final side=Path()..moveTo(x+w,y)..lineTo(x+w+d,y-d*.45)..lineTo(x+w+d,y+h-d*.45)..lineTo(x+w,y+h)..close();c.drawPath(side,Paint()..color=Colors.blueGrey.shade400);
 final q=Paint()..style=PaintingStyle.stroke..strokeWidth=2..color=Colors.indigo;c.drawRect(Rect.fromLTWH(x,y,w,h),q);
 for(int i=1;i<=m.shelves;i++){final yy=y+h*i/(m.shelves+1);c.drawLine(Offset(x+5,yy),Offset(x+w-5,yy),q);}
 for(int i=0;i<m.doors;i++){final dw=w/math.max(1,m.doors);c.drawRect(Rect.fromLTWH(x+i*dw+3,y+3,dw-6,h-6),q);}
 }@override bool shouldRepaint(covariant Painter old)=>true;}

class CutList extends StatelessWidget{const CutList({super.key});@override Widget build(BuildContext c)=>Consumer<CabinetModel>(builder:(c,m,_)=>
 Column(children:[ListTile(title:Text('${m.sheets} sheets • 2440 × 1220 mm'),subtitle:Text('Material area ${(m.area/1e6).toStringAsFixed(2)} m²')),
 Expanded(child:ListView(children:m.cuts.map((x)=>ListTile(leading:CircleAvatar(child:Text('${x.qty}')),title:Text(x.name),subtitle:Text('${x.w.toStringAsFixed(0)} × ${x.h.toStringAsFixed(0)} mm • ${x.edge}'))).toList())),
 Padding(padding:const EdgeInsets.all(12),child:FilledButton.icon(onPressed:()=>exportXlsx(m),icon:const Icon(Icons.table_chart),label:const Text('Export Excel .xlsx')))]));}
class Quote extends StatelessWidget{const Quote({super.key});@override Widget build(BuildContext c)=>Consumer<CabinetModel>(builder:(c,m,_)=>
 Center(child:Column(mainAxisAlignment:MainAxisAlignment.center,children:[Text('Cabinet ${m.width.toStringAsFixed(0)} × ${m.height.toStringAsFixed(0)} × ${m.depth.toStringAsFixed(0)} mm',style:Theme.of(c).textTheme.titleLarge),const SizedBox(height:10),Text('Estimated sheets: ${m.sheets}'),const SizedBox(height:20),FilledButton.icon(onPressed:()=>exportPdf(m),icon:const Icon(Icons.picture_as_pdf),label:const Text('Export PDF quotation'))]));}

Future<void> exportXlsx(CabinetModel m)async{final e=Excel.createExcel();final s=e['Cut List'];s.appendRow([TextCellValue('Part'),TextCellValue('Width mm'),TextCellValue('Height mm'),TextCellValue('Qty'),TextCellValue('Edge')]);for(final x in m.cuts)s.appendRow([TextCellValue(x.name),DoubleCellValue(x.w),DoubleCellValue(x.h),IntCellValue(x.qty),TextCellValue(x.edge)]);final d=await getApplicationDocumentsDirectory(),p='${d.path}/Melamina_Cut_List.xlsx',b=e.encode();if(b!=null){await File(p).writeAsBytes(b);await Share.shareXFiles([XFile(p)],text:'Melamina Pro cut list');}}
Future<void> exportPdf(CabinetModel m)async{final d=pw.Document();d.addPage(pw.Page(build:(_)=>pw.Column(crossAxisAlignment:pw.CrossAxisAlignment.start,children:[pw.Text('MELAMINA PRO — QUOTATION',style:pw.TextStyle(fontSize:20,fontWeight:pw.FontWeight.bold)),pw.SizedBox(height:10),pw.Text('Cabinet: ${m.width.toStringAsFixed(0)} × ${m.height.toStringAsFixed(0)} × ${m.depth.toStringAsFixed(0)} mm'),pw.Text('Board: ${m.thickness.toStringAsFixed(0)} mm | Door: ${m.doorStyle} | Edge: ${m.edge}'),pw.SizedBox(height:10),pw.Text('Estimated sheets: ${m.sheets}'),pw.SizedBox(height:10),pw.Table.fromTextArray(data:[['Part','W','H','Qty','Edge'],...m.cuts.map((x)=>[x.name,x.w.toStringAsFixed(0),x.h.toStringAsFixed(0),x.qty.toString(),x.edge])])])));final dir=await getApplicationDocumentsDirectory(),p='${dir.path}/Melamina_Quotation.pdf';await File(p).writeAsBytes(await d.save());await Share.shareXFiles([XFile(p)],text:'Melamina Pro quotation');}
