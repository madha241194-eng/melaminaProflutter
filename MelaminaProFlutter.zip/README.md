# Melamina Pro Flutter
Flutter conversion of the Melamina Pro cabinet designer.

Features: cabinet dimensions, visual preview, shelves, drawers, doors, door styles, edge banding, cut list, sheet estimate, PDF quotation and real XLSX export.

Build:
1. Install Flutter + Android Studio.
2. Extract this ZIP.
3. Run `flutter create .` inside the project folder to generate Android/iOS platform folders.
4. Run `flutter pub get`.
5. Run `flutter build apk --release`.

Note: the included preview is a lightweight cabinet visualizer. A production-grade release can add true orbit/zoom 3D, advanced nesting/kerf/grain constraints, hardware, materials, pricing and detailed drawings.
